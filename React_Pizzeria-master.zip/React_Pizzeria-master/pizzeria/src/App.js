import Nav from './comp/Nav';

function App() {
  return (
    <div>

      <Nav></Nav>
    </div>
  );
}

export default App;
